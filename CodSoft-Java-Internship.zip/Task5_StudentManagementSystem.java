import java.util.*;

class Student {
    String name;
    int roll;
    String grade;

    Student(String name, int roll, String grade) {
        this.name = name;
        this.roll = roll;
        this.grade = grade;
    }

    public String toString() {
        return "Roll: " + roll + ", Name: " + name + ", Grade: " + grade;
    }
}

public class StudentManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();
        int choice;

        do {
            System.out.println("\n1. Add Student\n2. View All\n3. Search by Roll\n4. Remove by Roll\n5. Exit");
            System.out.print("Choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    sc.nextLine(); // consume newline
                    String name = sc.nextLine();
                    System.out.print("Enter Roll No: ");
                    int roll = sc.nextInt();
                    System.out.print("Enter Grade: ");
                    String grade = sc.next();
                    students.add(new Student(name, roll, grade));
                    break;
                case 2:
                    for (Student s : students) System.out.println(s);
                    break;
                case 3:
                    System.out.print("Enter Roll No: ");
                    int r = sc.nextInt();
                    for (Student s : students) {
                        if (s.roll == r) System.out.println(s);
                    }
                    break;
                case 4:
                    System.out.print("Enter Roll to Remove: ");
                    int removeRoll = sc.nextInt();
                    students.removeIf(s -> s.roll == removeRoll);
                    System.out.println("Removed if existed.");
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
            }
        } while (choice != 5);

        sc.close();
    }
}