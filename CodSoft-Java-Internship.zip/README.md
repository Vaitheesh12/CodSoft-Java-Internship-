# CodSoft Java Internship Projects

This repository contains all 5 tasks completed as part of the CodSoft Java Development Internship.

## Tasks Implemented

1. **Number Guessing Game**
2. **Student Grade Calculator**
3. **ATM Interface**
4. **Currency Converter**
5. **Student Management System**

Each task demonstrates fundamental Java concepts such as:
- Loops and conditionals
- OOP (Object-Oriented Programming)
- Data structures (Array, ArrayList, HashMap)
- User input handling

## How to Run

Each `.java` file contains a standalone program. Compile and run them using any Java compiler.

Example:
```bash
javac Task1_NumberGuessGame.java
java NumberGuessGame
```

## Author

[Vaitheesh P](https://github.com/Vaitheesh12)