import java.util.*;

public class NumberGuessGame {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int score = 0;
        System.out.println("Welcome to Number Guessing Game!");
        boolean playAgain = true;

        while (playAgain) {
            int number = rand.nextInt(100) + 1;
            int attempts = 0, guess;
            boolean guessedCorrectly = false;
            System.out.println("Guess a number between 1 and 100. You have 5 attempts!");

            while (attempts < 5) {
                System.out.print("Enter guess: ");
                guess = sc.nextInt();
                attempts++;
                if (guess == number) {
                    System.out.println("Correct! You guessed in " + attempts + " attempts.");
                    score++;
                    guessedCorrectly = true;
                    break;
                } else if (guess < number) {
                    System.out.println("Too low!");
                } else {
                    System.out.println("Too high!");
                }
            }

            if (!guessedCorrectly) {
                System.out.println("You've used all attempts. The number was: " + number);
            }

            System.out.print("Play again? (yes/no): ");
            playAgain = sc.next().equalsIgnoreCase("yes");
        }

        System.out.println("Your total score: " + score);
        sc.close();
    }
}